﻿
Public Class Form1

    Public Class Customer
        Private name As String        'customer name'
        Private id As Integer         'customer id needs to be unique'
        Private city As String        'current city'
        Private state As String       'current state'
        Private zip As String         'current zip'
        Private phone As String       'phone'
        ' Private contact As String     'contact details...could be a mail id or a phone number'
        Private address As String
        Private contacts As List(Of String)

        Public Property customerName() As String
            Get
                Return Name
            End Get
            Protected Set(custName As String)
                name = custName
            End Set
        End Property


        Public Property customerCity() As String
            Get
                Return city
            End Get
            Protected Set(custCity As String)
                city = custCity
            End Set
        End Property

        Public Property customerState() As String
            Get
                Return state
            End Get
            Protected Set(custState As String)
                state = custState
            End Set
        End Property

        Public Property customerZip() As String
            Get
                Return zip
            End Get
            Protected Set(custZip As String)
                zip = custZip
            End Set
        End Property

        Public Property customerPhone() As String
            Get
                Return phone
            End Get
            Protected Set(custPhone As String)
                phone = custPhone
            End Set
        End Property

        ' returns address object
        'Public Property customerAddress() As Address
        '   Get
        '      Return address
        ' End Get
        'Protected Set(custAddress As Address)
        '   address = custAddress
        'End Set
        'End Property
        ' returns customer contact
        Public ReadOnly Property getContacts() As List(Of String)
            Get
                Return contacts
            End Get
        End Property

        Public Sub addContact(ByVal newContact As String)
            getContacts.Add(newContact)
        End Sub

        Public Sub New()
        End Sub

        Public Sub New(ByVal customerName As String, ByVal customerId As Integer, ByVal customerCity As String, ByVal customerState As String, ByVal customerZip As String, ByVal customerPhone As String, ByVal customerContact As String, ByVal line1 As String, Optional ByVal line2 As String = "", Optional ByVal line3 As String = "")
            name = customerName
            id = customerId
            city = customerCity
            state = customerState
            zip = customerZip
            phone = customerPhone
            contacts.Add(customerContact)
            address = line1 + "\n" + line2 + "\n" + line3
        End Sub

    End Class



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim BillingAddrSource As New AutoCompleteStringCollection()
        BillingAddrSource.AddRange(New String() _
                                  { _
                                    "12345", _
                                    "12346", _
                                    "12347" _
                                  })

        TextBox1.AutoCompleteCustomSource = BillingAddrSource
        TextBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        TextBox1.AutoCompleteSource = AutoCompleteSource.CustomSource



    End Sub

End Class
